var x = 50;
var y = 50;
var diameter = 25;
var mousex = 0;
var mousey = 0;
var x1 = 790;
var y1 = 500;
var x2 = 400;
var y2 = 400;
var x3 = 400;
var y3 = 400;
var movement = 13;


function setup() {
  createCanvas(800, 600);
}

function draw() {
  background(0);
  fill(24, 200, 29);
  circle(x, y, diameter);
  rect(790, 500, 10, 100);
  circle(x2, y2, 25)
  circle(x3, y3, 35)

  if (x > x1 && y > y1) {
    textSize(60);
    fill(24, 200, 29)
    text("You win", 400, 400);
    //console.log("You win!") This was for testing.

  }

  if (keyIsDown(83)) {
    y += 5;
  }
  else if (keyIsDown(87)) {
    y -= 5;
  }

  ellipse(mousex, mousey, 15, 50);
  if (x2 >= 800 || x2 <= 0) {
    movement *= 1;
    x2 = 0
  }
  x2 += movement;

  if (y3 >= 600 || y3 <= 0) {
    movement *= 1;
    y3 = 0
  }
  y3 += movement;


}

function keyPressed() {
  if (key == 'd') {
    x += 10;
  }
  else if (key == 'a') {
    x -= 10;
  }
}

function mouseClicked() {
  mousex = mouseX;
  mousey = mouseY;

}
